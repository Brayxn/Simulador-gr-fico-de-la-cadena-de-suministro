'use client';

/**
 * ============================================
 * HOOK USE-SIMULATION
 * ============================================
 * 
 * Hook personalizado que maneja toda la logica de la simulacion.
 * Incluye el estado del grafo, camion, animaciones y algoritmos.
 */

import { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import { 
  GraphNode, 
  GraphEdge, 
  Truck, 
  CalculatedRoute, 
  SimulationStats,
  SimulationState
} from '@/lib/graph-types';
import { INITIAL_NODES, INITIAL_EDGES, SIMULATION_CONFIG } from '@/lib/graph-data';
import { dijkstra, WeightType } from '@/lib/dijkstra';

export function useSimulation() {
  // Estado del grafo
  const [nodes, setNodes] = useState<GraphNode[]>(INITIAL_NODES);
  const [edges, setEdges] = useState<GraphEdge[]>(INITIAL_EDGES);

  // Estado de la simulacion
  const [simulationState, setSimulationState] = useState<SimulationState>({
    isRunning: false,
    isPaused: false,
    speed: 1,
    currentStep: 0,
    mode: 'normal'
  });

  // Estado del camion
  const [truck, setTruck] = useState<Truck>({
    id: 'truck-1',
    currentNodeId: 'factory-1',
    targetNodeId: null,
    cargo: 0,
    maxCargo: SIMULATION_CONFIG.truckCapacity,
    progress: 0,
    isMoving: false,
    speed: SIMULATION_CONFIG.baseSpeed
  });

  // Configuracion de ruta
  const [sourceNode, setSourceNode] = useState<string>('factory-1');
  const [targetNode, setTargetNode] = useState<string>('store-3');
  const [weightType, setWeightType] = useState<WeightType>('distance');

  // Ruta calculada - usando useMemo para evitar recalculos innecesarios
  const calculatedRoute = useMemo<CalculatedRoute | null>(() => {
    return dijkstra(INITIAL_NODES, INITIAL_EDGES, sourceNode, targetNode, weightType);
  }, [sourceNode, targetNode, weightType]);

  // Actualizar edges activos cuando cambia la ruta calculada
  useEffect(() => {
    if (calculatedRoute) {
      setEdges(INITIAL_EDGES.map(edge => ({
        ...edge,
        isActive: calculatedRoute.edges.some(e => e.id === edge.id)
      })));
    } else {
      setEdges(INITIAL_EDGES.map(e => ({ ...e, isActive: false })));
    }
  }, [calculatedRoute]);

  // Estadisticas
  const [stats, setStats] = useState<SimulationStats>({
    totalTransported: 0,
    totalCost: 0,
    totalDistance: 0,
    totalTime: 0,
    deliveriesCompleted: 0,
    efficiency: 0
  });

  // UI states
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [highlightedNodes, setHighlightedNodes] = useState<string[]>([]);
  const [highlightedEdges, setHighlightedEdges] = useState<string[]>([]);

  // Referencias para animacion
  const animationRef = useRef<number | null>(null);
  const routeIndexRef = useRef<number>(0);

  // Iniciar simulacion
  const startSimulation = useCallback(() => {
    if (!calculatedRoute || calculatedRoute.path.length < 2) {
      return;
    }

    // Cargar mercancia en el camion
    const sourceNodeObj = nodes.find(n => n.id === sourceNode);
    const cargoAmount = Math.min(
      SIMULATION_CONFIG.cargoPerDelivery,
      sourceNodeObj?.inventory.current || 0,
      SIMULATION_CONFIG.truckCapacity
    );

    // Actualizar inventario del origen (restar la carga)
    setNodes(prev => prev.map(node => {
      if (node.id === sourceNode) {
        return {
          ...node,
          inventory: {
            ...node.inventory,
            current: node.inventory.current - cargoAmount
          }
        };
      }
      return node;
    }));

    // Configurar camion para iniciar
    setTruck({
      id: 'truck-1',
      currentNodeId: calculatedRoute.path[0],
      targetNodeId: calculatedRoute.path[1],
      cargo: cargoAmount,
      maxCargo: SIMULATION_CONFIG.truckCapacity,
      progress: 0,
      isMoving: true,
      speed: SIMULATION_CONFIG.baseSpeed
    });

    routeIndexRef.current = 0;

    setSimulationState(prev => ({
      ...prev,
      isRunning: true,
      isPaused: false
    }));
  }, [calculatedRoute, nodes, sourceNode]);

  // Pausar simulacion
  const pauseSimulation = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
    setSimulationState(prev => ({
      ...prev,
      isRunning: false,
      isPaused: true
    }));
  }, []);

  // Reanudar simulacion
  const resumeSimulation = useCallback(() => {
    setSimulationState(prev => ({
      ...prev,
      isRunning: true,
      isPaused: false
    }));
  }, []);

  // Resetear simulacion
  const resetSimulation = useCallback(() => {
    // Cancelar animacion
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }

    // Resetear todos los estados
    setNodes(INITIAL_NODES);
    setTruck({
      id: 'truck-1',
      currentNodeId: 'factory-1',
      targetNodeId: null,
      cargo: 0,
      maxCargo: SIMULATION_CONFIG.truckCapacity,
      progress: 0,
      isMoving: false,
      speed: SIMULATION_CONFIG.baseSpeed
    });
    setStats({
      totalTransported: 0,
      totalCost: 0,
      totalDistance: 0,
      totalTime: 0,
      deliveriesCompleted: 0,
      efficiency: 0
    });
    setSimulationState({
      isRunning: false,
      isPaused: false,
      speed: 1,
      currentStep: 0,
      mode: 'normal'
    });
    routeIndexRef.current = 0;
    setHighlightedNodes([]);
    setHighlightedEdges([]);
    
    // Recalcular edges activos basado en la ruta
    const route = dijkstra(INITIAL_NODES, INITIAL_EDGES, sourceNode, targetNode, weightType);
    if (route) {
      setEdges(INITIAL_EDGES.map(edge => ({
        ...edge,
        isActive: route.edges.some(e => e.id === edge.id)
      })));
    } else {
      setEdges(INITIAL_EDGES.map(e => ({ ...e, isActive: false })));
    }
  }, [sourceNode, targetNode, weightType]);

  // Cambiar velocidad
  const setSpeed = useCallback((speed: number) => {
    setSimulationState(prev => ({ ...prev, speed }));
  }, []);

  // Alternar modo explicacion
  const toggleExplanationMode = useCallback(() => {
    setSimulationState(prev => ({
      ...prev,
      mode: prev.mode === 'explanation' ? 'normal' : 'explanation',
      currentStep: 0
    }));
  }, []);

  // Loop de animacion
  useEffect(() => {
    if (!simulationState.isRunning || !calculatedRoute) return;

    let lastTime = performance.now();
    
    const animate = (currentTime: number) => {
      const deltaTime = currentTime - lastTime;
      lastTime = currentTime;

      // Actualizar progreso del camion
      setTruck(prev => {
        if (!prev.isMoving) return prev;

        const speedMultiplier = simulationState.speed;
        const progressIncrement = (deltaTime / 1000) * 0.5 * speedMultiplier;
        const newProgress = prev.progress + progressIncrement;

        // Si llego al nodo destino actual del segmento
        if (newProgress >= 1) {
          const currentRouteIndex = routeIndexRef.current;
          const nextIndex = currentRouteIndex + 1;
          const arrivedNodeId = prev.targetNodeId || prev.currentNodeId;
          const finalDestination = calculatedRoute.path[calculatedRoute.path.length - 1];
          const isAtFinalDestination = arrivedNodeId === finalDestination;

          // Actualizar estadisticas de distancia/costo/tiempo por el segmento recorrido
          const currentEdge = calculatedRoute.edges[currentRouteIndex];
          if (currentEdge) {
            setStats(prevStats => ({
              ...prevStats,
              totalDistance: prevStats.totalDistance + currentEdge.distance,
              totalCost: prevStats.totalCost + currentEdge.cost,
              totalTime: prevStats.totalTime + currentEdge.time
            }));
          }

          // Determinar cuanto descargar segun el tipo de nodo
          // - Nodos intermedios (almacen/distribucion): descargan 10 unidades para procesamiento
          // - Destino final: descarga todo
          const arrivedNode = INITIAL_NODES.find(n => n.id === arrivedNodeId);
          const isIntermediateNode = arrivedNode && 
            (arrivedNode.type === 'warehouse' || arrivedNode.type === 'distribution');
          const unloadAmount = isAtFinalDestination 
            ? prev.cargo  // En destino final, descarga todo
            : (isIntermediateNode ? 10 : 0);  // En nodos intermedios, descarga 10

          // Actualizar inventario del nodo al que llegamos
          if (unloadAmount > 0) {
            setNodes(prevNodes => prevNodes.map(node => {
              if (node.id === arrivedNodeId) {
                const newCurrent = Math.min(
                  node.inventory.current + unloadAmount,
                  node.inventory.capacity
                );
                return {
                  ...node,
                  inventory: {
                    ...node.inventory,
                    current: newCurrent
                  },
                  status: newCurrent < node.inventory.capacity * 0.2 ? 'critical' :
                          newCurrent < node.inventory.capacity * 0.5 ? 'warning' : 'active'
                };
              }
              return node;
            }));
          }

          // Si es el destino final, completar la entrega
          if (isAtFinalDestination) {
            // Entrega completada
            setStats(prevStats => ({
              ...prevStats,
              totalTransported: prevStats.totalTransported + prev.cargo,
              deliveriesCompleted: prevStats.deliveriesCompleted + 1,
              efficiency: Math.min(100, ((prevStats.deliveriesCompleted + 1) / 
                (prevStats.totalCost / 100 + 1)) * 50)
            }));

            // Marcar simulacion como completada (no pausada, solo detenida)
            setSimulationState(prevState => ({
              ...prevState,
              isRunning: false,
              isPaused: false
            }));

            return {
              ...prev,
              currentNodeId: arrivedNodeId,
              targetNodeId: null,
              cargo: 0,
              progress: 0,
              isMoving: false
            };
          }

          // Si hay mas nodos en la ruta, continuar al siguiente
          if (nextIndex < calculatedRoute.path.length) {
            routeIndexRef.current = nextIndex;
            const newCargo = prev.cargo - unloadAmount;  // Restar lo que descargo
            
            return {
              ...prev,
              currentNodeId: arrivedNodeId,
              targetNodeId: calculatedRoute.path[nextIndex],
              progress: 0,
              cargo: Math.max(0, newCargo)  // Asegurar que no sea negativo
            };
          }
        }

        return { ...prev, progress: newProgress };
      });

      if (simulationState.isRunning) {
        animationRef.current = requestAnimationFrame(animate);
      }
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [simulationState.isRunning, simulationState.speed, calculatedRoute]);

  // Click en nodo
  const handleNodeClick = useCallback((node: GraphNode) => {
    setSelectedNode(prev => prev?.id === node.id ? null : node);
  }, []);

  // Funcion para toggle pause/resume - memoizada
  const togglePause = useCallback(() => {
    if (simulationState.isPaused) {
      resumeSimulation();
    } else {
      pauseSimulation();
    }
  }, [simulationState.isPaused, pauseSimulation, resumeSimulation]);

  // Funciones de highlight memoizadas
  const updateHighlightedNodes = useCallback((nodes: string[]) => {
    setHighlightedNodes(nodes);
  }, []);

  const updateHighlightedEdges = useCallback((edges: string[]) => {
    setHighlightedEdges(edges);
  }, []);

  return {
    // Estado
    nodes,
    edges,
    truck,
    calculatedRoute,
    stats,
    simulationState,
    selectedNode,
    highlightedNodes,
    highlightedEdges,
    
    // Configuracion
    sourceNode,
    targetNode,
    weightType,
    
    // Acciones
    setSourceNode,
    setTargetNode,
    setWeightType,
    startSimulation,
    pauseSimulation: togglePause,
    resetSimulation,
    setSpeed,
    toggleExplanationMode,
    handleNodeClick,
    setHighlightedNodes: updateHighlightedNodes,
    setHighlightedEdges: updateHighlightedEdges,
    setSimulationState
  };
}
