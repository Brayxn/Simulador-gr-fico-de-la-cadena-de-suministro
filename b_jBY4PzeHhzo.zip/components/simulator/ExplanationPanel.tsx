'use client';

/**
 * ============================================
 * COMPONENTE EXPLANATIONPANEL
 * ============================================
 * 
 * Panel de explicación educativa para el modo demostración.
 * Muestra paso a paso los conceptos de teoría de grafos.
 */

import { motion, AnimatePresence } from 'framer-motion';
import { ExplanationStep } from '@/lib/graph-types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  ChevronLeft, 
  ChevronRight, 
  X,
  BookOpen,
  Lightbulb,
  Network,
  GitBranch,
  Target,
  Route,
  CheckCircle2
} from 'lucide-react';

interface ExplanationPanelProps {
  steps: ExplanationStep[];
  currentStep: number;
  onNextStep: () => void;
  onPrevStep: () => void;
  onClose: () => void;
  isAnimating: boolean;
}

// Iconos para cada paso
const stepIcons: Record<string, React.ReactNode> = {
  '1': <Network className="w-6 h-6" />,
  '2': <Target className="w-6 h-6" />,
  '3': <GitBranch className="w-6 h-6" />,
  '4': <Route className="w-6 h-6" />,
  '5': <Lightbulb className="w-6 h-6" />,
  '6': <Target className="w-6 h-6" />,
  '7': <CheckCircle2 className="w-6 h-6" />,
};

export default function ExplanationPanel({
  steps,
  currentStep,
  onNextStep,
  onPrevStep,
  onClose,
  isAnimating
}: ExplanationPanelProps) {
  const step = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;

  if (!step) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className="absolute bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-[450px] z-50"
    >
      <Card className="border-accent bg-card/95 backdrop-blur-sm shadow-2xl">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/20 text-accent">
                {stepIcons[step.id.toString()] || <BookOpen className="w-6 h-6" />}
              </div>
              <div>
                <Badge variant="outline" className="mb-1 text-[10px]">
                  Paso {currentStep + 1} de {steps.length}
                </Badge>
                <CardTitle className="text-lg text-foreground">
                  {step.title}
                </CardTitle>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
          <Progress value={progress} className="h-1 mt-3" />
        </CardHeader>
        
        <CardContent className="space-y-4">
          <AnimatePresence mode="wait">
            <motion.p
              key={step.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="text-sm text-muted-foreground leading-relaxed"
            >
              {step.description}
            </motion.p>
          </AnimatePresence>

          {/* Indicadores de acción */}
          {step.action === 'calculate' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-2 p-3 rounded-lg bg-accent/10 border border-accent/30"
            >
              <div className="animate-pulse">
                <Lightbulb className="w-5 h-5 text-accent" />
              </div>
              <span className="text-sm text-accent">
                Observa cómo el algoritmo calcula la mejor ruta...
              </span>
            </motion.div>
          )}

          {step.action === 'animate' && isAnimating && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-2 p-3 rounded-lg bg-primary/10 border border-primary/30"
            >
              <div className="animate-bounce">
                <Route className="w-5 h-5 text-primary" />
              </div>
              <span className="text-sm text-primary">
                Sigue el movimiento del camión por la ruta...
              </span>
            </motion.div>
          )}

          {step.action === 'complete' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-2 p-3 rounded-lg bg-chart-3/10 border border-chart-3/30"
            >
              <CheckCircle2 className="w-5 h-5 text-chart-3" />
              <span className="text-sm text-chart-3">
                ¡Demostración completada!
              </span>
            </motion.div>
          )}

          {/* Navegación */}
          <div className="flex items-center justify-between pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onPrevStep}
              disabled={currentStep === 0}
              className="border-border"
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Anterior
            </Button>
            
            <div className="flex gap-1">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentStep 
                      ? 'bg-accent' 
                      : index < currentStep 
                        ? 'bg-accent/50' 
                        : 'bg-muted'
                  }`}
                />
              ))}
            </div>

            <Button
              variant={currentStep === steps.length - 1 ? 'default' : 'outline'}
              size="sm"
              onClick={currentStep === steps.length - 1 ? onClose : onNextStep}
              className={currentStep === steps.length - 1 ? 'bg-accent text-accent-foreground' : 'border-border'}
            >
              {currentStep === steps.length - 1 ? 'Finalizar' : 'Siguiente'}
              {currentStep !== steps.length - 1 && <ChevronRight className="w-4 h-4 ml-1" />}
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
